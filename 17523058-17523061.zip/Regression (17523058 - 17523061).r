
MyData <- read.csv(file="rmr.csv", header=TRUE, sep=",")
MyData

poly_model <- lm(metabolic.rate ~ poly(body.weight,degree=2), data = MyData)
poly_model

x <- with(MyData, seq(min(body.weight), max(body.weight), length.out=2000))
y <- predict(poly_model, newdata = data.frame(body.weight = x))

plot(metabolic.rate ~ body.weight, data = MyData)
lines(x, y, col = "red")

s=predict(poly_model, newdata = data.frame(body.weight = 70))
s

model <-lm(metabolic.rate ~ body.weight, data=MyData)
summary(model)

plot(metabolic.rate ~ body.weight, data=MyData)
abline(model, col = "red", lwd = 1)

predict(model, data.frame(body.weight= 70))
